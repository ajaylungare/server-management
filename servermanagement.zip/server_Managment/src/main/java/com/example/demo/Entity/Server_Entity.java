package com.example.demo.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Servers")
public class Server_Entity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long Sr_no;
	private Integer pontNum;
	private String serverName;
	private String enviroment;
	private String project;
	private String operatingSystem;
	private String commisionedDate;
	private String expityDate;
	private String serverHealth;
	
	
	
	
	
	public Server_Entity() {
			}

	
	
	public Server_Entity(Long sr_no, Integer pontNum, String serverName, String enviroment, String project,
			String operatingSystem, String commisionedDate, String expityDate, String serverHealth) {
		super();
		Sr_no = sr_no;
		this.pontNum = pontNum;
		this.serverName = serverName;
		this.enviroment = enviroment;
		this.project = project;
		this.operatingSystem = operatingSystem;
		this.commisionedDate = commisionedDate;
		this.expityDate = expityDate;
		this.serverHealth = serverHealth;
	}



	public Long getSr_no() {
		return Sr_no;
	}



	public void setSr_no(Long sr_no) {
		Sr_no = sr_no;
	}



	public Integer getPontNum() {
		return pontNum;
	}



	public void setPontNum(Integer pontNum) {
		this.pontNum = pontNum;
	}



	public String getServerName() {
		return serverName;
	}



	public void setServerName(String serverName) {
		this.serverName = serverName;
	}



	public String getEnviroment() {
		return enviroment;
	}



	public void setEnviroment(String enviroment) {
		this.enviroment = enviroment;
	}



	public String getProject() {
		return project;
	}



	public void setProject(String project) {
		this.project = project;
	}



	public String getOperatingSystem() {
		return operatingSystem;
	}



	public void setOperatingSystem(String operatingSystem) {
		this.operatingSystem = operatingSystem;
	}



	public String getCommisionedDate() {
		return commisionedDate;
	}



	public void setCommisionedDate(String commisionedDate) {
		this.commisionedDate = commisionedDate;
	}



	public String getExpityDate() {
		return expityDate;
	}



	public void setExpityDate(String expityDate) {
		this.expityDate = expityDate;
	}



	public String getServerHealth() {
		return serverHealth;
	}



	public void setServerHealth(String serverHealth) {
		this.serverHealth = serverHealth;
	}



	@Override
	public String toString() {
		return "server_Entity [Sr_no=" + Sr_no + ", pontNum=" + pontNum + ", serverName=" + serverName + ", enviroment="
				+ enviroment + ", project=" + project + ", operatingSystem=" + operatingSystem + ", commisionedDate="
				+ commisionedDate + ", expityDate=" + expityDate + ", serverHealth=" + serverHealth + "]";
	}
	
	
	
	
}


	
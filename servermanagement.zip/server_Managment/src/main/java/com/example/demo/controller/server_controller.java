package com.example.demo.controller;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.Entity.Server_Entity;
import com.example.demo.Entity.login_Entity;
import com.example.demo.service.server_service;

@Controller
public class server_controller {
	
	@Autowired
	private server_service service;
	
	
	@GetMapping("/")
	public String login() {
		
		return "index";
	}
	
	@PostMapping("/login")
	public String welcome(login_Entity login) {
		return service.Login(login);
	
	}
	
	@GetMapping("/success")
	public String f2() {
		
		return "success";
	}
	
	
	@GetMapping("/form")
	public String f1() {	
		
		return "form";
	}
	
	
	
	@GetMapping("/view") 
	public String getServer(Model model) {
		List<Server_Entity> serverlist = service.listAll();
		model.addAttribute("server_Entity", serverlist); 
		return "listAll";
	}
	
	
	@PostMapping("/save")
	public String saveServer(@ModelAttribute Server_Entity server, BindingResult result) {
		service.saveServer(server);
		return "add";
		
	}
	
	
	@GetMapping("/edit/{id}")
	public String showEditForm(@PathVariable("id") Long id, Model model) {
	    Server_Entity server = service.findById(id);
	    
	    model.addAttribute("server", server);
	    return "edit_server";
	}

	
	
	@PostMapping("edit/update")
	public String updateServer(@ModelAttribute Server_Entity server, BindingResult result) {
	    service.saveServer(server);
	    return "redirect:/view"; 
	}

	
	@GetMapping("/delete/{id}")
	public String deleteServer(@PathVariable("id") Long id) {
		service.delete(id);
		return "redirect:/view";		
	}
	
	
	
	
}

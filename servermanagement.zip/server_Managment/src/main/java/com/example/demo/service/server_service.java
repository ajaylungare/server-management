package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.login_Entity;
import com.example.demo.Entity.Server_Entity;
import com.example.demo.repository.server_repository;

@Service
public class server_service {
	@Autowired
	private server_repository repo;
	
	
	public String Login(login_Entity login) {
		System.out.println("un :"+login.getUsername());
		System.out.println("pass :"+login.getPassword());
		
		if((login.getUsername().equals("Ajay")) && (login.getPassword().equals("1234"))) {
			return "success";			
		}else {
			return "fail";
		}
					
	}

	public Server_Entity saveServer(Server_Entity server) { 
		return repo.save(server);
	}

	public void delete(long id) {
		repo.deleteById(id);	
		
	}

	public List<Server_Entity> listAll() {
		return repo.findAll();
	}

	public Server_Entity findById(Long id) {
        Optional<Server_Entity> serverOptional = repo.findById(id);
        return serverOptional.orElse(null);
    }

	public void update(Server_Entity server) {
		// TODO Auto-generated method stub
		
	}

}
